
#include <stdio.h>

int main()
{
	printf("hello, there.\n\nmy name is not important\n\tand im here to save you-cw og-mark hamill\n\b");
	
	char s[128];
	
	printf("Enter your name:\n");
	gets(s);
	
	printf("You typed: %s\n",s);

	
	return 0;
}
