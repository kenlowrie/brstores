#!/usr/bin/env python3

def decode(html_string):
    try:
        from HTMLParser import HTMLParser
    except ImportError:
        from html.parser import HTMLParser

    h = HTMLParser()
    return h.unescape(html_string)



import re

x="""<div class="wrapper">
    <div class="extras">
        <p>I'm using the variable <a href="&#109;a&#x69;l&#x74;o&#x3a;&#109;&#x79;&#101;&#x6d;&#97;i&#108;&#64;&#x6d;y&#x64;&#111;&#x6d;&#97;&#x69;&#110;&#x2e;&#99;o&#109;">me</a>.</p>
    </div>
    <div class="extras">
        <p>Now I'm using the <a href="&#109;&#x61;i&#x6c;t&#111;&#x3a;&#101;&#x6d;a&#105;&#x6c;&#64;&#x79;o&#117;&#x72;&#100;&#x6f;m&#x61;i&#110;&#x2e;&#99;&#x6f;m&#63;&#x73;&#117;&#x62;j&#101;&#x63;&#116;&#x3d;Y&#111;&#x75;&#114;&#x25;2&#x30;F&#105;&#x6c;&#109;&#x25;2&#48;&#x54;&#105;&#x74;l&#101;&#x25;&#50;&#x30;F&#x65;e&#100;&#x62;a&#x63;k">feedback</a> variable.</p>
    </div>
</div>"""

g1 = r'<a href=\"(.*)\">([\w]*)</a>'
from re import findall, match

# Find all the <p class="revTitle">Revision: n (date @ time)</p> lines
m = findall(g1,x)
print(len(m))
print(m)
for rev_set in m:
    # extract the revision and timestamp from a match
    email,var = rev_set
    # extract the date and time
    print("email={}".format(decode(email)))
    print("var={}".format(var))
