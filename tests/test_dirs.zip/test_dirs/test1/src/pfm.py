
poo = True
mcgoo = False

print "poo = ", poo
print "mcgoo = ", mcgoo

if poo == True:
	print "bandit is a cone head somethimes"
else:
	print "my brother is obsessed with trucks and it gets on my nerves......:("


x=1
while x != '0':
	print "you have to enter 0 to stop this"
	print
	x = raw_input("enter something: ")
	if x != 0:
		print "my brother is a pooper scooper"
	x = raw_input("poop: ")
	 
	poo = True